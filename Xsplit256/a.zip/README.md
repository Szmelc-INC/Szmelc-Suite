# Xsplit256
=============================
| [README.md] 4 [Xsplit256] |
| [/github.com/GNU-Szmelc]  |
=============================

### Run demo
> Execute in terminal... \

bash split.sh a.zip && sleep 2
bash combine.sh split_files/a.zip
sleep 2 && bash verify.sh

### More

### About

### Contribute
