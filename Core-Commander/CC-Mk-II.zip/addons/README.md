# Addons Panel
## Core.sh Readme MkI
