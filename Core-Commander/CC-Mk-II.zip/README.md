# Command & Control panel
## GNU-Szmelc

> EXPERIMENTAL COMMANDER
> FULL GNU DIALOG
