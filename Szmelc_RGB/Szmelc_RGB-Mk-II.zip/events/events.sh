echo "Events" | figlet | lolcat
echo "" && sleep 2 && bash exec.sh
