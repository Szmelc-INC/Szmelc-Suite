
# Post Install Scripts for Debian based distros (APT)

### [INFO]
> Run `install.sh` before running Commander_x64 \
> Logs are saved into logs directory \
> Currently installed_packages.txt log overwrites itself to save only most recent version \
> Add / Remove any packages by editing packages.txt via Install Szmelc Wizard or manually \

### [LINKS]
> https://github.com/GNU-Szmelc \
> https://discord.gg/y9h7FjVsX6 \
